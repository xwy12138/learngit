﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "src/pcl_tree_all.h"
#include "src/mouse_cloud.h"
#include "src/match_tree.h"
#include "src/treeDetact.h"
#include "src/io.h"
#include <string>
#include <thread>
#include <chrono>
#include<future>      //std::future std::promise
#include<utility>     //std::ref
#include <pthread.h>

QString mainT[2];
QString filename1;
QString filename2;

int vp,vpp,next_step=0,cloud_type=0;
treeDetact tree1,tree2;
bool FileLoaded0 = false;
bool FileLoaded1 = false;
bool correctCloud_flag=false;
bool dangerCloud_flag=false;
bool matchCloud_flag=false;
bool migrateCloud_flag=false;
bool settree_flag = false;
bool fileread_flag = false;
bool tree_cenrtoid=false;
std::string filename_cloud1;
std::string filename_cloud2;
//*************************** read PCD file1*****************************************
pcl::PointCloud<pcl::PointXYZ>::Ptr cloud1(new pcl::PointCloud<pcl::PointXYZ>);
pcl::PointCloud<pcl::PointXYZL>::Ptr cloud1l(new pcl::PointCloud<pcl::PointXYZL>);

pcl::PointCloud<pcl::PointXYZL>::Ptr cloud1_tower(new pcl::PointCloud<pcl::PointXYZL>);
pcl::PointCloud<pcl::PointXYZL>::Ptr cloud1_line(new pcl::PointCloud<pcl::PointXYZL>);
pcl::PointCloud<pcl::PointXYZL>::Ptr cloud1_tree(new pcl::PointCloud<pcl::PointXYZL>);
pcl::PointCloud<pcl::PointXYZL>::Ptr cloud1_ground(new pcl::PointCloud<pcl::PointXYZL>);

//*************************** read PCD file2*****************************************
pcl::PointCloud<pcl::PointXYZ>::Ptr cloud2(new pcl::PointCloud<pcl::PointXYZ>);
pcl::PointCloud<pcl::PointXYZL>::Ptr cloud2l(new pcl::PointCloud<pcl::PointXYZL>);

pcl::PointCloud<pcl::PointXYZL>::Ptr cloud2_tower(new pcl::PointCloud<pcl::PointXYZL>);
pcl::PointCloud<pcl::PointXYZL>::Ptr cloud2_line(new pcl::PointCloud<pcl::PointXYZL>);
pcl::PointCloud<pcl::PointXYZL>::Ptr cloud2_tree(new pcl::PointCloud<pcl::PointXYZL>);
pcl::PointCloud<pcl::PointXYZL>::Ptr cloud2_ground(new pcl::PointCloud<pcl::PointXYZL>);

//****************************************************************************************
pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZL> handler1_tree   (cloud1_tree,   0,255,0);
pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZL> handler1_tower  (cloud1_tower,  255,0,0);
pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZL> handler1_line   (cloud1_line,   0,0,255);
pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZL> handler1_ground (cloud1_ground, 50,50,50);
pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZL> handler2_tree   (cloud2_tree,   0,255,0);
pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZL> handler2_tower  (cloud2_tower,  255,0,0);
pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZL> handler2_line   (cloud2_line,   0,0,255);
pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZL> handler2_ground (cloud2_ground, 50,50,50);

pcl::PointCloud<pcl::PointXYZL>::Ptr pointSelected(new pcl::PointCloud<pcl::PointXYZL>);
pcl::PointCloud<pcl::PointXYZL>::Ptr pointSelected2(new pcl::PointCloud<pcl::PointXYZL>);
pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZL> handler_selected   (pointSelected,   255,255,0);
pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZL> handler_selected2  (pointSelected2,  0,255,255);
//**********************************  match  ***********************************************
pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZL> handler_cloud1(cloud1l,0,0,255);
pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> handler_cloud2(cloud2,0,255,0);

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    iniUI();

    pcdviewer.reset (new pcl::visualization::PCLVisualizer ("pcdviewer", false));
    pcdviewer->setBackgroundColor (0.1, 0.1, 0.1);
    ui->widget->SetRenderWindow(pcdviewer->getRenderWindow());
    pcdviewer->setupInteractor(ui->widget->GetInteractor(),ui->widget->GetRenderWindow());

    pcdviewer2.reset (new pcl::visualization::PCLVisualizer ("pcdviewer2", false));
    pcdviewer2->setBackgroundColor (0.1, 0.1, 0.1);
    ui->widget_2->SetRenderWindow(pcdviewer2->getRenderWindow());
    pcdviewer2->setupInteractor(ui->widget_2->GetInteractor(),ui->widget_2->GetRenderWindow());
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::iniUI()
{
    fileLoadingBar = new QProgressBar;
    mmigrateLoadingBar = new QProgressBar;
    dangerLoadingBar = new QProgressBar;

    ui->label_PcFileName1->setText("");
    ui->label_PcFileName2->setText("");
    ui->label_PcFileName1->setMaximumHeight(20);
    ui->label_PcFileName2->setMaximumHeight(20);
    ui->treeWidget->setMaximumWidth(200);
    ui->label_PcFileName1->setMinimumWidth(500);
    ui->widget->setMaximumHeight(2160);
    ui->widget_2->setMaximumHeight(0);
    ui->treeWidget->setColumnCount(1);
    ui->treeWidget->setHeaderLabel(tr("工作空间"));
    message = new QLabel("请点击“打开”按钮，选择两份点云文件。");
    ui->statusBar->addWidget(message);
}

void MainWindow::setTree()
{
    QStringList mlist0 = mainT[0].split("/");
    QStringList mlist01 = mainT[1].split("/");
    filename1 = mlist0.last();
    filename2 = mlist01.last();

    QStringList mlist1 = filename1.split("-");
    QStringList mlist2 = filename2.split("-");
    filename1 = mlist1.last();
    filename2 = mlist2.last();
    filename_cloud1= filename1.toStdString();
    filename_cloud2= filename2.toStdString();

    filepath = new QTreeWidgetItem(ui->treeWidget,QStringList(QString("文件目录")));
    pcdfile1 = new QTreeWidgetItem(filepath,QStringList(QString(filename1)));
    pcdfile2 = new QTreeWidgetItem(filepath,QStringList(QString(filename2)));
    pc1 = new QTreeWidgetItem(pcdfile1,QStringList(QString("树木点云")));
    pc2 = new QTreeWidgetItem(pcdfile1,QStringList(QString("杆塔点云")));
    pc3 = new QTreeWidgetItem(pcdfile1,QStringList(QString("电线点云")));
    pc4 = new QTreeWidgetItem(pcdfile1,QStringList(QString("地面点云")));
    pc5 = new QTreeWidgetItem(pcdfile2,QStringList(QString("树木点云")));
    pc6 = new QTreeWidgetItem(pcdfile2,QStringList(QString("杆塔点云")));
    pc7 = new QTreeWidgetItem(pcdfile2,QStringList(QString("电线点云")));
    pc8 = new QTreeWidgetItem(pcdfile2,QStringList(QString("地面点云")));
    pcMatch1 = new QTreeWidgetItem(pcdfile1,QStringList(QString("匹配点云")));
    pcMatch2 = new QTreeWidgetItem(pcdfile2,QStringList(QString("匹配点云")));
    pc1->setFlags(Qt::ItemIsSelectable | Qt::ItemIsUserCheckable | Qt::ItemIsEnabled);
    pc2->setFlags(Qt::ItemIsSelectable | Qt::ItemIsUserCheckable | Qt::ItemIsEnabled);
    pc3->setFlags(Qt::ItemIsSelectable | Qt::ItemIsUserCheckable | Qt::ItemIsEnabled);
    pc4->setFlags(Qt::ItemIsSelectable | Qt::ItemIsUserCheckable | Qt::ItemIsEnabled);
    pc5->setFlags(Qt::ItemIsSelectable | Qt::ItemIsUserCheckable | Qt::ItemIsEnabled);
    pc6->setFlags(Qt::ItemIsSelectable | Qt::ItemIsUserCheckable | Qt::ItemIsEnabled);
    pc7->setFlags(Qt::ItemIsSelectable | Qt::ItemIsUserCheckable | Qt::ItemIsEnabled);
    pc8->setFlags(Qt::ItemIsSelectable | Qt::ItemIsUserCheckable | Qt::ItemIsEnabled);
    pcMatch1->setFlags(Qt::ItemIsSelectable | Qt::ItemIsUserCheckable | Qt::ItemIsEnabled);
    pcMatch2->setFlags(Qt::ItemIsSelectable | Qt::ItemIsUserCheckable | Qt::ItemIsEnabled);
    pc1->setCheckState(0,Qt::Unchecked);
    pc2->setCheckState(0,Qt::Unchecked);
    pc3->setCheckState(0,Qt::Unchecked);
    pc4->setCheckState(0,Qt::Unchecked);
    pc5->setCheckState(0,Qt::Unchecked);
    pc6->setCheckState(0,Qt::Unchecked);
    pc7->setCheckState(0,Qt::Unchecked);
    pc8->setCheckState(0,Qt::Unchecked);
    pcMatch1->setCheckState(0,Qt::Unchecked);
    pcMatch2->setCheckState(0,Qt::Unchecked);
    pcdfile2->removeChild(pc5);
    pcdfile2->removeChild(pc6);
    pcdfile2->removeChild(pc7);
    pcdfile2->removeChild(pc8);
    pcdfile1->removeChild(pcMatch1);
    pcdfile2->removeChild(pcMatch2);
    ui->treeWidget->expandAll();
    settree_flag = true;//优化
}

void fileread()
{
    if (pcl::io::loadPCDFile<pcl::PointXYZL>(mainT[0].toStdString(), *cloud1l) == -1){
        std::cerr << "open failed!" << std::endl;
        FileLoaded0 = false;
    }
    else{
        pcl::VoxelGrid<pcl::PointXYZL> filter;
        FileLoaded0 = true;
    }
    if (pcl::io::loadPCDFile<pcl::PointXYZ>(mainT[1].toStdString(), *cloud2) == -1){
        std::cerr << "open failed!" << std::endl;
        FileLoaded1 = false;
    }
    else{
        pcl::VoxelGrid<pcl::PointXYZ> filter;
        FileLoaded1 = true;
    }
    if(FileLoaded0 && FileLoaded1){
        for(size_t i=0; i<cloud1l->size();i++){
            pcl::PointXYZL myPoint;
            myPoint.x=cloud1l->points[i].x;
            myPoint.y=cloud1l->points[i].y;
            myPoint.z=cloud1l->points[i].z;
            myPoint.label=cloud1l->points[i].label;

            switch(cloud1l->points[i].label){
            case 0 :
                cloud1_tower->push_back(myPoint);
                break;
            case 1 :
                cloud1_line->push_back(myPoint);
                break;
            case 2 :
                cloud1_tree->push_back(myPoint);
                break;
            case 3 :
                cloud1_ground->push_back(myPoint);
                break;
            }
        }
        fileread_flag = true;
    }
}

void MainWindow::on_actionopen_triggered()
{
    QFileDialog add_file_dialog;
    add_file_dialog.setFileMode(QFileDialog::ExistingFiles);
    //有点bug，是同时输入较早时间的pcd（xyzl）和txt，和最新时间的pcd（xyz）
    //输入点云文件1有标签，有危险树木的csv
    //根据标签切成3个文件，分别是只有杆塔，只有树木，只有电线的
    //并且用全局变量保存 之后在树状图访问
    QStringList filename=add_file_dialog.getOpenFileNames(
                this, tr("open point cloud"),".", tr("select(*.pcd)"));
    int i=0;
    for(auto temp:filename){
        mainT[i++]=temp;
    }

    if(mainT[0].size() != 0 && mainT[1].size() != 0){
        //文件名时间samll的放前面
        QString time0 = mainT[0].right(12).left(8);
        QString time1 = mainT[1].right(12).left(8);
        if(time0 < time1){
            QString exchangemainT;
            exchangemainT = mainT[0];
            mainT[0] = mainT[1];
            mainT[1] = exchangemainT;
        }

        std::thread fr(fileread);
        fr.detach();

        ui->label_PcFileName1->setText(mainT[0]);
        ui->label_PcFileName2->setText(mainT[1]);
        message->setText("加载中:");
        ui->statusBar->addWidget(fileLoadingBar);
        fileLoadingBar->setRange(0,100);
        fileLoadingBar->setValue(0);
//        fileLoadingBar->setAlignment(Qt::AlignHCenter);

        for(int t=1; t<41; t++){//wait
            if(fileread_flag) break;
            fileLoadingBar->setValue(t);
            QApplication::processEvents();
            usleep(60000);
        }
        for(int t=40; t<81; t++){//wait
            if(fileread_flag) break;
            fileLoadingBar->setValue(t);
            QApplication::processEvents();
            usleep(40000);
        }
        for(int t=80; t<99; t++){//wait
            if(fileread_flag) break;
            fileLoadingBar->setValue(t);
            QApplication::processEvents();
            usleep(20000);
        }
        for(int t=0; t<1800; t++){//wait 30m
            if(fileread_flag) break;
            fileLoadingBar->setValue(99);
            QApplication::processEvents();
            sleep(1);
        }

        fileLoadingBar->setValue(100);

        if(fileread_flag){
            //*************************** display file1 *******************
            pcdviewer->createViewPort(0.0, 0.0, 1.0, 1.0, vp);
            //*************************** display file2 *******************
            pcdviewer2->createViewPort(0.0, 0.0, 1.0, 1.0, vp);
            cout<<"s"<<endl;
            ui->widget->update();
            ui->widget_2->update();
            //****************************** 加载完成 **********************
            ui->statusBar->removeWidget(fileLoadingBar);
            message->setText("");
            setTree();
            message->setText("请勾选点云，进行查看和修正。");
            ui->statusBar->removeWidget(fileLoadingBar);
            QMessageBox::information(this, tr("信息"), tr("文件加载成功！"));
        }
        else
            QMessageBox::information(this, tr("信息"), tr("文件加载失败！"));
    }
    else
        QMessageBox::information(this, tr("信息"), tr("文件打开失败！"));
}

void MainWindow::on_actionsave_triggered()
{
    //    //点云文件2输出保存带标签的，以及新的危险树木点云
    if(fileread_flag)//如果标记为1，证明有文件加载，不然没有不需要保存
    {
        QString saveName,savePath,filePath;
        QDateTime time = QDateTime::currentDateTime();//获取系统现在的时间
        QString str = time.toString("mm:ss-yyyyMMdd"); //设置显示格式

        filePath = QFileDialog::getExistingDirectory(this,"");//获取文件夹路径
        if(filePath.isEmpty())
            QMessageBox::information(this,"信息","保存失败！");
        else
        {
            if(pc1->checkState(0) == Qt::Checked && !cloud1_tree->empty()){//cloud_tree
                saveName="cloud1_tree";
                savePath=QString("%1/%2-%3.pcd").arg(filePath).arg(saveName).arg(str);
                const std::string savePCL = savePath.toStdString();
                std::cout<<"tree"<<std::endl;
                pcl::io::savePCDFileBinary(savePCL,*cloud1_tree);
            }
            if(pc2->checkState(0) == Qt::Checked && !cloud1_tower->empty()){//cloud_tower
                saveName="cloud1_tower";
                savePath=QString("%1/%2-%3.pcd").arg(filePath).arg(saveName).arg(str);
                const std::string savePCL = savePath.toStdString();
                pcl::io::savePCDFileBinary(savePCL,*cloud1_tower);
            }
            if(pc3->checkState(0) == Qt::Checked && !cloud1_line->empty()){//cloud_line
                saveName="cloud1_line";
                savePath=QString("%1/%2-%3.pcd").arg(filePath).arg(saveName).arg(str);
                const std::string savePCL = savePath.toStdString();
                pcl::io::savePCDFileBinary(savePCL,*cloud1_line);

            }
            if(pc4->checkState(0) == Qt::Checked && !cloud1_ground->empty()){//cloud_ground
                saveName="cloud1_ground";
                savePath=QString("%1/%2-%3.pcd").arg(filePath).arg(saveName).arg(str);
                const std::string savePCL = savePath.toStdString();
                pcl::io::savePCDFileBinary(savePCL,*cloud1_ground);

            }
            if(pc5->checkState(0) == Qt::Checked && !cloud2_tree->empty()){//cloud_tree
                saveName="cloud2_tree";
                savePath=QString("%1/%2-%3.pcd").arg(filePath).arg(saveName).arg(str);
                const std::string savePCL = savePath.toStdString();
                pcl::io::savePCDFileBinary(savePCL,*cloud2_tree);
            }
            if(pc6->checkState(0) == Qt::Checked && !cloud2_tower->empty()){//cloud_tower
                saveName="cloud2_tower";
                savePath=QString("%1/%2-%3.pcd").arg(filePath).arg(saveName).arg(str);
                const std::string savePCL = savePath.toStdString();
                pcl::io::savePCDFileBinary(savePCL,*cloud2_tower);
            }
            if(pc7->checkState(0) == Qt::Checked && !cloud2_line->empty()){//cloud_line
                saveName="cloud2_line";
                savePath=QString("%1/%2-%3.pcd").arg(filePath).arg(saveName).arg(str);
                const std::string savePCL = savePath.toStdString();
                pcl::io::savePCDFileBinary(savePCL,*cloud2_line);
            }
            if(pc8->checkState(0) == Qt::Checked && !cloud2_ground->empty()){//cloud_ground
                saveName="cloud2_ground";
                savePath=QString("%1/%2-%3.pcd").arg(filePath).arg(saveName).arg(str);
                const std::string savePCL = savePath.toStdString();
                pcl::io::savePCDFileBinary(savePCL,*cloud2_ground);
            }
            QMessageBox::information(this,"信息","保存成功！");
        }
    }
    else
        QMessageBox::information(this,"信息","文件未导入！");

}

void MainWindow::on_actionfrontView_triggered()
{
    //    //设置视点
    //shoulin/mc
    if(fileread_flag){
        pcdviewer->resetCamera();
        pcdviewer2->resetCamera();
        ui->widget->update();
        ui->widget_2->update();
    }
    else
        QMessageBox::information(this,"信息","文件未导入！");
}

void correct_cloud(boost::shared_ptr<pcl::visualization::PCLVisualizer> pcdviewer,
                   QWidget* win,pcl::PointCloud<pcl::PointXYZL>::Ptr cloud)
{
    pcdviewer->removeAllPointClouds(vp);
    win->update();
    //    //寿麟老哥来写
    correctClouds cloud_correct(pcdviewer);
    std::cout<<"1"<<endl;

    cloud_correct.setInputCloud(cloud);
    pcl::visualization::PointCloudColorHandlerGenericField<pcl::PointXYZL> correct_handler_tower  (cloud,"z");
    pcdviewer->addPointCloud(cloud,correct_handler_tower,"Cloud",vp);
    win->update();
    next_step=-1;

    std::cout<<"2"<<endl;
    while(1)
    {
        if(next_step==1)
            break;
        else{
            win->update();
            QApplication::processEvents();
            usleep(1000);
        }}

    pcdviewer->removePointCloud("Cloud");
    std::cout<<"3"<<endl;
    cloud_correct.getclouds(pointSelected,pointSelected2);

    pcdviewer->removeAllPointClouds(vp);
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZL> correct_handler_pointSelected2(pointSelected2,  255,0,0);
    pcdviewer->addPointCloud(pointSelected2,correct_handler_pointSelected2, "Cloud",vp);
    win->update();
    std::cout<<"5"<<endl;
}

void changelabel(pcl::PointCloud<pcl::PointXYZL>::Ptr cloud,float label)
{
    for(int i=0;i<cloud->size();i++)
    {
        cloud->points[i].label=label;
        QApplication::processEvents();
    }
}

void MainWindow::on_actioncorrect_triggered()
{
    if(fileread_flag)
    {
    ui->statusBar->addWidget(message);
    message->setText("请在左边选择需要修正的点云，按“x”键，然后用鼠标框选点云，再按“x”退出框选。请依次点击“完成”,“归类”按钮,完成重新分类操作。");
    if(fileread_flag){
        correctCloud_flag=true;

        if(pc1->checkState(0) == Qt::Checked){
            correct_cloud(pcdviewer,ui->widget,cloud1_tree);
            changelabel(pointSelected2,2);
            *cloud1_tree = *pointSelected2;
        }

        if(pc2->checkState(0) == Qt::Checked){
            correct_cloud(pcdviewer,ui->widget,cloud1_tower);
            changelabel(pointSelected2,0);
            *cloud1_tower = *pointSelected2;
        }

        if(pc3->checkState(0) == Qt::Checked){
            correct_cloud(pcdviewer,ui->widget,cloud1_line);
            changelabel(pointSelected2,1);
            *cloud1_line = *pointSelected2;
        }

        if(pc4->checkState(0) == Qt::Checked){
            correct_cloud(pcdviewer,ui->widget,cloud1_ground);
            changelabel(pointSelected2,3);
            *cloud1_ground = *pointSelected2;
        }

        QMessageBox::information(this, tr("信息"), tr("点云选择成功！请点击“归类”按钮。"));

    }
    else
        QMessageBox::information(this,"信息","文件未导入！");
    }

}

void pick_match(boost::shared_ptr<pcl::visualization::PCLVisualizer> pcdviewer,
                QWidget* win,
                pcl::PointCloud<pcl::PointXYZ>::Ptr cloud1,
                pcl::PointCloud<pcl::PointXYZ>::Ptr &cloud2)
{
    pcl::PointCloud<pcl::PointXYZ>::Ptr myPylon1(new pcl::PointCloud<pcl::PointXYZ>);
    pcl::PointCloud<pcl::PointXYZ>::Ptr myPylon2(new pcl::PointCloud<pcl::PointXYZ>);

    //myPointCloudPtr2
    std::cout<<"1"<<std::endl;
    //-------------------------------------
    mouse(cloud1, myPylon1,pcdviewer,win,filename_cloud1);
    std::cout<<"2"<<std::endl;
    mouse(cloud2, myPylon2,pcdviewer,win,filename_cloud2);
    std::cout<<"3"<<std::endl;

    //------------------icp----------------
    match match_test(myPylon1,myPylon2,cloud1,cloud2);
    std::cout<<"4"<<std::endl;

    cloud2=match_test.cloud_merga;
    std::cout<<"5"<<std::endl;

}

void MainWindow::on_actionpcmatch_triggered()
{
    message->setText("请按shift和鼠标左键选择一个点，按“完成”按钮，然后再选一个点，按“完成”按钮。");
    if(fileread_flag)
    {
        pc1->setCheckState(0,Qt::Unchecked);
        pc2->setCheckState(0,Qt::Unchecked);
        pc3->setCheckState(0,Qt::Unchecked);
        pc4->setCheckState(0,Qt::Unchecked);

    //点云文件2选点做一个icp shoulin
        pcl::copyPointCloud(*cloud1_tower,*cloud1);
        pick_match(pcdviewer,ui->widget,cloud1,cloud2);

        message->setText("程序正在执行，请稍候。");
        pcdviewer->removeAllPointClouds(vp);
//        pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZL> handler_cloud1(cloud1l,0,0,255);
//        pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> handler_cloud2(cloud2,0,255,0);
        pcdviewer->addPointCloud(cloud1l, handler_cloud1,"Cloud1",vp);
        pcdviewer->addPointCloud(cloud2, handler_cloud2,"Cloud2",vp);
        settree_flag = false;
        pcdfile1->addChild(pcMatch1);
        pcdfile2->addChild(pcMatch2);
        pcMatch1->setCheckState(0,Qt::Checked);
        pcMatch2->setCheckState(0,Qt::Checked);
        settree_flag = true;
        ui->widget->update();
        message->setText("匹配点云完成。");
        matchCloud_flag=true;
    }
    else
        QMessageBox::information(this,"信息","点云未修正！");

}

void cloud_mmigrate(pcl::PointCloud<pcl::PointXYZL>::Ptr cloud1l,
                    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud2,
                    pcl::PointCloud<pcl::PointXYZL>::Ptr &cloud2l)
{
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloudmo_nl(new pcl::PointCloud<pcl::PointXYZ>());

    pcl::copyPointCloud(*cloud1l,*cloudmo_nl);
    //KD树建立
    pcl::KdTreeFLANN<pcl::PointXYZ>kdtree;
    kdtree.setInputCloud(cloudmo_nl);//设置搜索空间
    cloud2l->resize(cloud2->size());
    cloud2l->width=cloud2->size();
    cloud2l->height=1;
    cloud2l->is_dense=false;
    // k近邻搜索
    int K = 1;
    std::vector<int>pointIdxNKNSearch(K);//存储搜索到查询点紧邻的索引
    std::vector<float>pointNKNSquaredDistance(K);//存储搜对应的近邻距离平方 ，打印相关信息

    for (size_t i = 0; i < cloud2->size(); i++) {
        if (kdtree.nearestKSearch(cloud2->points[i], K, pointIdxNKNSearch, pointNKNSquaredDistance) > 0)//执行k近邻搜索
        {
            cloud2l->points[i].x=cloud2->points[i].x;
            cloud2l->points[i].y=cloud2->points[i].y;
            cloud2l->points[i].z=cloud2->points[i].z;
            cloud2l->points[i].label = cloud1l->points[pointIdxNKNSearch[0]].label;		//将最近邻的标签给该点
        }
        QApplication::processEvents();
    }
}

void mmigrateloading(QProgressBar *p){
    for(int i = 0; i < 51; i++){
        if(migrateCloud_flag){
            p->setValue(100);
            break;
        }
        p->setValue(i);
        QApplication::processEvents();
        usleep(40000);
    }

    for(int i = 50; i < 90; i++){
        if(migrateCloud_flag){
            p->setValue(100);
            break;
        }
        p->setValue(i);
        QApplication::processEvents();
        usleep(70000);
    }

    for(int i = 90; i < 100; i++){
        if(migrateCloud_flag){
            p->setValue(100);
            break;
        }
        p->setValue(i);
        QApplication::processEvents();
        usleep(100000);
    }


}
void dangerloading(QProgressBar *p){
    for(int i = 0; i < 100; i++){
        if(dangerCloud_flag){
            p->setValue(100);
            break;
        }
        p->setValue(i);
        QApplication::processEvents();
        usleep(30000);
    }
}

void MainWindow::on_actionmmigrate_triggered()
{
    if(matchCloud_flag)
   {
        message->setText("正在进行点云迁移，请稍候。");
        ui->widget_2->setMaximumHeight(2160);

        ui->statusBar->addWidget(mmigrateLoadingBar);
        mmigrateLoadingBar->setRange(0,100);
        mmigrateLoadingBar->setValue(0);
        mmigrateLoadingBar->setAlignment(Qt::AlignHCenter);

        std::thread mml(mmigrateloading,mmigrateLoadingBar);
        mml.detach();

        pcl::VoxelGrid<pcl::PointXYZL> filter;
        filter.setInputCloud(cloud1l);
        filter.setLeafSize(0.3f,0.3f,0.3f);
        filter.filter(*cloud1l);

        pcl::VoxelGrid<pcl::PointXYZ> filter2;
        filter2.setInputCloud(cloud2);
        filter2.setLeafSize(0.3f,0.3f,0.3f);
        filter2.filter(*cloud2);

        std::cout<<"start cloud migration"<<std::endl;

        cloud_mmigrate(cloud1l, cloud2,cloud2l);
        for(size_t i=0; i<cloud2l->size();i++){
            pcl::PointXYZL myPoint;
            myPoint.x=cloud2l->points[i].x;
            myPoint.y=cloud2l->points[i].y;
            myPoint.z=cloud2l->points[i].z;
            myPoint.label=cloud2l->points[i].label;

            switch(cloud2l->points[i].label){
            case 0 :
                cloud2_tower->push_back(myPoint);
                break;
            case 1 :
                cloud2_line->push_back(myPoint);
                break;
            case 2 :
                cloud2_tree->push_back(myPoint);
                break;
            case 3 :
                cloud2_ground->push_back(myPoint);
                break;
            }
            QApplication::processEvents();
        }

        settree_flag = false;
        pcdfile2->addChild(pc5);
        pcdfile2->addChild(pc6);
        pcdfile2->addChild(pc7);
        pcdfile2->addChild(pc8);
        pcdfile1->removeChild(pcMatch1);
        pcdfile2->removeChild(pcMatch2);
        pcMatch1->setCheckState(0,Qt::Unchecked);
        pcMatch2->setCheckState(0,Qt::Unchecked);
        pc1->setCheckState(0,Qt::Checked);
        pc2->setCheckState(0,Qt::Checked);
        pc3->setCheckState(0,Qt::Checked);
        pc4->setCheckState(0,Qt::Checked);
        pc5->setCheckState(0,Qt::Checked);
        pc6->setCheckState(0,Qt::Checked);
        pc7->setCheckState(0,Qt::Checked);
        settree_flag = true;
        pc8->setCheckState(0,Qt::Checked);

        migrateCloud_flag=true;
        ui->statusBar->removeWidget(mmigrateLoadingBar);
        message->setText("点云迁移完成。");
        QMessageBox::information(this,"信息","点云迁移完成！");
    }
    else
        QMessageBox::information(this,"信息","点云未匹配！");

}

void MainWindow::on_actiondanger_triggered()
{
    if(matchCloud_flag)
    {
    //    //点云文件2选取危险通道
    //    //危险通道内的树木进行分割成一株一株,所有树木都是危险树木
    //    //跟点云文件1的危险树木用kdtree找对应的。两株树木最高的50个点做差，为树木生长情况
    //    //保存树线距离,保存危险树木经纬度情况
        std::cout<<"start cloud dangerpoint"<<std::endl;
        message->setText("正在进行危险点检测，请稍候。");

        ui->statusBar->addWidget(dangerLoadingBar);
        dangerLoadingBar->setRange(0,100);
        dangerLoadingBar->setValue(0);
//        dangerLoadingBar->setAlignment(Qt::AlignHCenter);

        std::thread mml(dangerloading,dangerLoadingBar);
        mml.detach();

        int myLabel=2;
        //对树木点云求出质心点
        tree1.getCentroid(cloud1l,myLabel);
        tree2.getCentroid(cloud2l,myLabel);
        tree1.dangerDetact(tree2);
        tree_cenrtoid=true;
        pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> handler_tree1   (tree1.tree_cenrtoid, 255,255,255);
        pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> handler_tree2   (tree2.tree_cenrtoid, 255,255,255);
        
        pcdviewer->addPointCloud<pcl::PointXYZ>(tree1.tree_cenrtoid, handler_tree1, "tree1", vp);
        pcdviewer2->addPointCloud<pcl::PointXYZ>(tree2.tree_cenrtoid, handler_tree2, "tree2", vp);
        
        pcdviewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 10, "tree1");
        pcdviewer2->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 10, "tree2");
        ui->widget->update();
        ui->widget_2->update();
        dangerCloud_flag=true;
        message->setText("检测完成。");
        ui->statusBar->removeWidget(dangerLoadingBar);
        QMessageBox::information(this,"信息","检测完成！");
    }
    else
        QMessageBox::information(this,"信息","点云未匹配！");
}

void MainWindow::on_treeWidget_itemChanged(QTreeWidgetItem *item, int column)
{
    if(settree_flag){
        std::cout<<"you have picked2"<<std::endl;
        pcdviewer->removeAllPointClouds(vp);
        pcdviewer2->removeAllPointClouds(vp);

        if(pc1->checkState(0) == Qt::Checked){//cloud_tree
            cloud_type=0;
            pcdviewer->addPointCloud(cloud1_tree,   handler1_tree,   "id1_tree",   vp);
        }
        else {
            pcdviewer->removePointCloud("id1_tree",   vp);
        }

        if(pc2->checkState(0) == Qt::Checked){//cloud_tower
            cloud_type=1;
            pcdviewer->addPointCloud(cloud1_tower,  handler1_tower,  "id1_tower",  vp);
        }
        else {
            pcdviewer->removePointCloud("id1_tower",   vp);
        }

        if(pc3->checkState(0) == Qt::Checked){//cloud_line
            cloud_type=2;
            pcdviewer->addPointCloud(cloud1_line,   handler1_line,   "id1_line",   vp);
        }
        else {
            pcdviewer->removePointCloud("id1_line",   vp);
        }

        if(pc4->checkState(0) == Qt::Checked){//cloud_ground
            cloud_type=3;
            pcdviewer->addPointCloud(cloud1_ground, handler1_ground, "id1_ground", vp);
        }
        else {
            pcdviewer->removePointCloud("id1_ground",   vp);
        }

        if(matchCloud_flag){
            if(pc5->checkState(0) == Qt::Checked){//cloud_tree
                pcdviewer2->addPointCloud(cloud2_tree,   handler2_tree,   "id2_tree",   vp);
            }
            else {
                pcdviewer2->removePointCloud("id2_tree",   vp);
            }

            if(pc6->checkState(0) == Qt::Checked){//cloud_tower
                pcdviewer2->addPointCloud(cloud2_tower,  handler2_tower,  "id2_tower",  vp);
            }
            else {
                pcdviewer2->removePointCloud("id2_tower",   vp);
            }

            if(pc7->checkState(0) == Qt::Checked){//cloud_line
                pcdviewer2->addPointCloud(cloud2_line,   handler2_line,   "id2_line",   vp);
            }
            else {
                pcdviewer2->removePointCloud("id2_line",   vp);
            }

            if(pc8->checkState(0) == Qt::Checked){//cloud_ground
                pcdviewer2->addPointCloud(cloud2_ground, handler2_ground, "id2_ground", vp);
            }
            else {
                pcdviewer2->removePointCloud("id2_ground",   vp);
            }
        }

        if(pcMatch1->checkState(0) == Qt::Checked){//cloud_ground
            pcdviewer->addPointCloud(cloud1l, handler_cloud1,"Cloud1",vp);
        }
        else {
            pcdviewer->removePointCloud("Cloud1",   vp);
        }

        if(pcMatch2->checkState(0) == Qt::Checked){//cloud_ground
            pcdviewer->addPointCloud(cloud2, handler_cloud2,"Cloud2",vp);
        }
        else {
            pcdviewer->removePointCloud("Cloud2",   vp);
        }

        if(tree_cenrtoid)
        {
            pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> handler_tree1   (tree1.tree_cenrtoid, 255,255,255);
            pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> handler_tree2   (tree2.tree_cenrtoid, 255,255,255);
            pcdviewer->addPointCloud<pcl::PointXYZ>(tree1.tree_cenrtoid, handler_tree1, "tree1", vp);
            pcdviewer2->addPointCloud<pcl::PointXYZ>(tree2.tree_cenrtoid, handler_tree2, "tree2", vp);
            pcdviewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 10, "tree1");
            pcdviewer2->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 10, "tree2");
        }
        pcdviewer2->resetCamera();
        pcdviewer->resetCamera();

        ui->widget->update();
        ui->widget_2->update();

    }
}

void MainWindow::on_actionreset_triggered()
{

    FileLoaded0 = false;
    FileLoaded1 = false;
    settree_flag = false;
    correctCloud_flag=false;
    dangerCloud_flag=false;
    matchCloud_flag=false;
    migrateCloud_flag=false;
    settree_flag = false;
    fileread_flag = false;
    mainT[0]="";
    mainT[1]="";
    filename_cloud1 = "";
    filename_cloud2 = "";
    vp=0;
    vpp=0;
    next_step=1;
    pcdviewer->removeAllPointClouds();
    pcdviewer2->removeAllPointClouds();
    ui->widget->update();
    ui->widget_2->update();
    ui->treeWidget->clear();
    ui->label_PcFileName1->setText("");
    ui->label_PcFileName2->setText("");
    cloud1->clear();
    cloud1l->clear();
    cloud1_line->clear();
    cloud1_tower->clear();
    cloud1_tree->clear();
    cloud1_ground->clear();
    cloud2->clear();
    cloud2l->clear();
    cloud2_line->clear();
    cloud2_tower->clear();
    cloud2_tree->clear();
    cloud2_ground->clear();
    message->setText("请点击“打开”按钮，选择两份点云文件。");

    QMessageBox::information(this,"信息","已重置！");

}

void MainWindow::on_actionnext_triggered()
{
    if(next_step == -1)
    {
       next_step =1;
    }
    else
        next_step =-1;
    std::cout<<"you have picked"<<std::endl;
}

void MainWindow::on_actionremoveall_triggered()
{
    pcdviewer->removeAllPointClouds(vp);
    ui->widget->update();
    pcdviewer2->removeAllPointClouds(vp);
    ui->widget_2->update();
}

void MainWindow::on_actionreturn_triggered()
{
    if(correctCloud_flag){
        QStringList items; //ComboBox 列表的内容
        items <<"树木点云"<<"杆塔点云"<<"电线点云"<<"地面点云";
        QString dlgTitle="归类框选点云";
        QString txtLabel="请选择点云";
        int  curIndex=0; //初始选择项
        bool editable=false; //ComboBox是否可编辑
        bool ok=false;
        QString text = QInputDialog::getItem(this, dlgTitle,txtLabel,items,curIndex,editable,&ok);
        const std::string texts = text.toStdString();
        if (ok && !text.isEmpty()){
            if(text == pc1->text(0)){//树木点云
                *cloud1_tree=*cloud1_tree+*pointSelected;
            }
            else if(text == pc2->text(0)){//杆塔点云
                *cloud1_tower=*cloud1_tower+*pointSelected;
            }
            else if(text == pc3->text(0)){//电线点云
                *cloud1_line=*cloud1_line+*pointSelected;
            }
            else if(text == pc4->text(0)){//地面点云
                *cloud1_ground=*cloud1_ground+*pointSelected;
            }
            QMessageBox::information(this, tr("信息"), tr("点云修正成功！"));
            pc1->setCheckState(0,Qt::Unchecked);
            pc2->setCheckState(0,Qt::Unchecked);
            pc3->setCheckState(0,Qt::Unchecked);
            pc4->setCheckState(0,Qt::Unchecked);

        }
    }else
        QMessageBox::information(this, tr("信息"), tr("点云未修正！"));

}

void findzmaxpoint(std::vector<pcl::PointCloud<pcl::PointXYZ>::Ptr> cloud_tree,
                   std::vector<pcl::PointXYZ> &points)
{
    float z_max=0;
    pcl::PointXYZ point;
    for(size_t i=0;i<cloud_tree.size();i++)
    {

        for(size_t j=0;j<cloud_tree[i]->size();j++)
        {
        if(cloud_tree[i]->points[j].z>z_max)
        {
            point=cloud_tree[i]->points[j];
        }
        }
        points.push_back(point);
    }
}

void findnearlinedist(pcl::PointCloud<pcl::PointXYZL>::Ptr cloud_line,
                      pcl::PointCloud<pcl::PointXYZ>::Ptr points,
                      std::vector<double> &points_height)
{
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_lines(new pcl::PointCloud<pcl::PointXYZ>());
    pcl::copyPointCloud(*cloud_line,*cloud_lines);
    //KD树建立
    pcl::KdTreeFLANN<pcl::PointXYZ>kdtree;
    kdtree.setInputCloud(cloud_lines);//设置搜索空间
    // k近邻搜索
    int K = 1;
    std::vector<int>pointIdxNKNSearch(K);//存储搜索到查询点紧邻的索引
    std::vector<float>pointNKNSquaredDistance(K);//存储搜对应的近邻距离平方 ，打印相关信息
    for (size_t i = 0; i < points->size(); i++) {
        if (kdtree.nearestKSearch(points->points[i], K, pointIdxNKNSearch, pointNKNSquaredDistance) > 0)//执行k近邻搜索
        {
            float temp = pointNKNSquaredDistance[0];
            temp = sqrt(temp);
            points_height.push_back(temp);
        }
    }
}

void convert_utm_lonlat(const pcl::PointXYZ utm_coord, const int utmzone, pcl::PointXYZ &lon_lat_coord)
{
    //建立投影坐标系到经纬度坐标系的转换
    OGRSpatialReference *RefSource = new OGRSpatialReference;
    RefSource->SetWellKnownGeogCS("WGS84");
    RefSource->SetProjCS("UTM(WGS84) in northern hemisphere.");
    RefSource->SetUTM(utmzone, TRUE);
    OGRSpatialReference *RefTarget = new OGRSpatialReference;
    RefTarget = RefSource->CloneGeogCS();
    OGRCoordinateTransformation *poTranform = OGRCreateCoordinateTransformation(RefSource, RefTarget);

    OGRPoint *poPoint = new OGRPoint();
    double tempx = utm_coord.x;
    double tempy = utm_coord.y;
    double tempz = utm_coord.z;

    poTranform->Transform(1, &tempx, &tempy, NULL);
    lon_lat_coord = pcl::PointXYZ(tempx, tempy, tempz);
}

void utm2lonlat(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud,pcl::PointCloud<pcl::PointXYZ>::Ptr &cloud_lonlat)
{

    size_t count=cloud->size();
    cloud_lonlat->resize(count);
    cloud_lonlat->width=count;
    cloud_lonlat->height=1;
    cloud_lonlat->is_dense=false;
    for(size_t i=0;i<cloud->size();i++)
    convert_utm_lonlat(cloud->points[i],49,cloud_lonlat->points[i]);
}
void findgrow(std::vector<pcl::PointXYZ> tree1zmaxpoints,std::vector<pcl::PointXYZ> tree2zmaxpoints,vector<int> correspondence,std::vector<float> &growths)
{
    for(int i=0;i<correspondence.size();i++)
    {
        growths.push_back(tree2zmaxpoints[correspondence[i]].z-tree1zmaxpoints[i].z);
    }
}
void MainWindow::on_actioncreatereport_triggered()
{
    if(dangerCloud_flag){
    std::vector<pcl::PointXYZ> tree1zmaxpoints;
    std::vector<pcl::PointXYZ> tree2zmaxpoints;
    std::vector<double> tree1linedist;
    std::vector<double> tree2linedist;
    pcl::PointCloud<pcl::PointXYZ>::Ptr tree1_lonlat(new pcl::PointCloud<pcl::PointXYZ>());
    pcl::PointCloud<pcl::PointXYZ>::Ptr tree2_lonlat(new pcl::PointCloud<pcl::PointXYZ>());

    std::vector<float> growths;
    findzmaxpoint(tree1.tree,tree1zmaxpoints);
    findzmaxpoint(tree2.tree,tree2zmaxpoints);
    //findgrow(tree1zmaxpoints,tree2zmaxpoints,tree1.correspondence,growths);
    findnearlinedist(cloud1_line,tree1.tree_cenrtoid,tree1linedist);
    findnearlinedist(cloud2_line,tree2.tree_cenrtoid,tree2linedist);

    utm2lonlat(tree1.tree_cenrtoid,tree1_lonlat);
    utm2lonlat(tree2.tree_cenrtoid,tree2_lonlat);
    QString saveName="危险点检测报告";
    QDateTime time = QDateTime::currentDateTime();//获取系统现在的时间
    QString str = time.toString("mm:ss-yyyyMMdd"); //设置显示格式
    QString filePath = QFileDialog::getExistingDirectory(this,"");//获取文件夹路径
    QString savePath=QString("%1/%2-%3.csv").arg(filePath).arg(saveName).arg(str);
    const std::string savereportname = savePath.toStdString();
    // 写文件
    std::string timeOld = filename1.split("_").first().toStdString();
    std::string timeNew = filename2.split("_").first().toStdString();
    ofstream outFile;
    outFile.open(savereportname, ios::out); // 打开模式可省略
    outFile <<setiosflags(ios::left)<<setw(5)<< "编号" <<setw(5)<< ','
            << setw(5)<<" "<<timeOld<< "树木中心点经度 " <<setw(5)<< ','<<setw(5)<<" "<<timeOld<<"树木中心点纬度 " <<setw(5)<< ','<<setw(5)<<" "<<timeOld<<"树木中心点高度 " <<setw(5)<< ','
            <<setw(5)<<" "<<timeNew<< "树木中心点经度 " <<setw(5)<<',' <<setw(5)<<" "<<timeNew<< "树木中心点纬度 " <<setw(5)<<","<<setw(5)<<" "<<timeNew<< "树木中心点高度 " <<setw(5)<<","
            <<setw(5)<<" "<<timeNew<< "距电线距离 "<<setw(5)<< ',' <<setw(5)<<" 生长高度 "<<setw(5)<<resetiosflags(ios::left)<<endl;
    for(size_t i=0;i<tree1.correspondence.size();i++)
    {
    outFile <<setiosflags(ios::left)<<setw(5)<< i << ',' << setiosflags(ios::fixed)<<setprecision(6)
            <<setw(5)<< tree1_lonlat->points[i].x << ','<<setw(5)<< tree1_lonlat->points[i].y << ','<<setw(5)<< tree1_lonlat->points[i].z << ','
            <<setw(5)<< tree2_lonlat->points[tree1.correspondence[i]].x << ','<<setw(5)<< tree2_lonlat->points[tree1.correspondence[i]].y << ','<<setw(5)<< tree2_lonlat->points[tree1.correspondence[i]].z << ','
            <<setw(5)<< tree2linedist[tree1.correspondence[i]]<<',' <<setw(5)<<tree1.growth[i]<<resetiosflags(ios::left)<<endl;
    }
    outFile.close();
//    std::cout<<"ok"<<std::endl;
    QMessageBox::information(this, tr("信息"), tr("导出成功！"));
    }else
        QMessageBox::information(this, tr("信息"), tr("导出失败！"));
}
