﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QPushButton>
#include <QLabel>
#include <QTreeWidget>
#include <QLabel>
#include <QMessageBox>
#include <QDateTime>
#include <QProgressBar>
#include <QInputDialog>

#include <vtkRenderWindow.h>//注意添加这个头文件，不添加会报错，但是这个头文件会带来编译时间大大增加
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/visualization/pcl_visualizer.h>


#include <iostream>
#include <vector>

 //Boost
#include <boost/math/special_functions/round.hpp>

extern int next_step;
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    QLabel *message;
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    boost::shared_ptr<pcl::visualization::PCLVisualizer> pcdviewer;
    boost::shared_ptr<pcl::visualization::PCLVisualizer> pcdviewer2;

public slots:

private slots:
    void on_actionopen_triggered();
    void on_actionsave_triggered();
    void on_actionfrontView_triggered();
    void on_actioncorrect_triggered();
    void on_actionmmigrate_triggered();
    void on_actiondanger_triggered();
    void on_actionpcmatch_triggered();
    void on_actionreset_triggered();
    void on_treeWidget_itemChanged(QTreeWidgetItem *item, int column);
    void on_actionnext_triggered();
    void on_actionremoveall_triggered();
    void on_actionreturn_triggered();
    void on_actioncreatereport_triggered();

private:
    Ui::MainWindow *ui;
    void iniUI();
    void setTree();
    QProgressBar *fileLoadingBar,*mmigrateLoadingBar,*dangerLoadingBar;
    QTreeWidgetItem *filepath;
    QTreeWidgetItem *pcdfile1,*pcdfile2;
    QTreeWidgetItem *pc1,*pc2,*pc3,*pc4,*pc5,*pc6,*pc7,*pc8,*pcMatch1,*pcMatch2;

};

#endif // MAINWINDOW_H
