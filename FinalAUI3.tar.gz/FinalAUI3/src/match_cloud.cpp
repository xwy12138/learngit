﻿#include"match_cloud.h"

void match::fliter()
{

    //(pcl::PointCloud<pcl::PointXYZ>::Ptr)cloud_pylon_need2match_f (new pcl::PointCloud<pcl::PointXYZ>);
    //(pcl::PointCloud<pcl::PointXYZ>::Ptr)cloud_pylon_need2match_f (new pcl::PointCloud<pcl::PointXYZ>);

    pcl::RadiusOutlierRemoval<pcl::PointXYZ> outrem;
    // build the filter
    outrem.setInputCloud(cloud_pylon_need2match);
    outrem.setRadiusSearch(1);
    outrem.setMinNeighborsInRadius (30);
    // apply filter
    outrem.filter(cloud_pylon_need2match_ff);

    outrem.setInputCloud(cloud_pylon_2match);
    outrem.filter(cloud_pylon_2match_ff);

    cloud_pylon_need2match_f = cloud_pylon_need2match_ff.makeShared();
    cloud_pylon_2match_f = cloud_pylon_2match_ff.makeShared();
    cloud_pylon_need2match.reset();
    cloud_pylon_2match.reset();
    //pcl::RadiusOutlierRemoval<pcl::PointXYZ> _outrem;
    // build the filter
    //_outrem.setInputCloud(cloud_pylon_2match);
    //_outrem.setRadiusSearch(1);
    //_outrem.setMinNeighborsInRadius (30);
    // apply filter
    //_outrem.filter (*cloud_pylon_2match);
}

bool match::pure_translation()
{
    double sum_x_1,sum_y_1,sum_z_1,sum_x_2,sum_y_2,sum_z_2,
            average_x_1,average_y_1,average_z_1,
            average_x_2,average_y_2,average_z_2,
            average_x,average_y,average_z;
    sum_x_1 = sum_y_1 = sum_z_1 = sum_x_2 = sum_y_2 = sum_z_2 =  0;

    for(int i=0;i<cloud_pylon_2match_f->points.size();++i)
    {
        sum_x_1 = cloud_pylon_2match_f->points[i].x + sum_x_1;
        sum_y_1 = cloud_pylon_2match_f->points[i].y + sum_y_1;
        sum_z_1 = cloud_pylon_2match_f->points[i].z + sum_z_1;
    }

    average_x_1 = sum_x_1/cloud_pylon_2match_f->points.size();
    average_y_1 = sum_y_1/cloud_pylon_2match_f->points.size();
    average_z_1 = sum_z_1/cloud_pylon_2match_f->points.size();

    for(int i=0;i<cloud_pylon_need2match_f->points.size();++i)
    {
        sum_x_2 = cloud_pylon_need2match_f->points[i].x + sum_x_2;
        sum_y_2 = cloud_pylon_need2match_f->points[i].y + sum_y_2;
        sum_z_2 = cloud_pylon_need2match_f->points[i].z + sum_z_2;
    }

    average_x_2 = sum_x_2/cloud_pylon_need2match_f->points.size();
    average_y_2 = sum_y_2/cloud_pylon_need2match_f->points.size();
    average_z_2 = sum_z_2/cloud_pylon_need2match_f->points.size();

    average_x = average_x_2 - average_x_1;
    average_y = average_y_2 - average_y_1;
    average_z = average_z_2 - average_z_1;

    transformation_matrix<<1,0,0,average_x,
            0,1,0,average_y,
            0,0,1,average_z,
            0,0,0,1;
    std::cout<<"pure_tansformation_transformation_matrix:"<<"\n"<<transformation_matrix<<std::endl;
}

bool match::IterativeClosestPoint()		
{
    iterations = 200;
    pcl::IterativeClosestPoint<pcl::PointXYZ, pcl::PointXYZ> icp;
    icp.setMaximumIterations (iterations);
    icp.setMaxCorrespondenceDistance(6);
    icp.setTransformationEpsilon(1e-10);
    icp.setEuclideanFitnessEpsilon(0.001);
    icp.setInputSource (cloud_pylon_2match_f);
    icp.setInputTarget (cloud_pylon_need2match_f);
    pcl::PointCloud<pcl::PointXYZ> Final;
    icp.align (Final);

    //TODO output time
    //std::cout << "Applied " << iterations << " ICP iteration(s) in " << time.toc () << " ms" << std::endl;

    if (icp.hasConverged ())
    {
        std::cout << "\nICP has converged, score is " << icp.getFitnessScore () << std::endl;
        std::cout << "\nICP transformation " << iterations << " : cloud_pylon_2match_f -> cloud_pylon_need2match_f" << std::endl;
        transformation_matrix = icp.getFinalTransformation ().cast<double>();
        std::cout<<"icp_transformation_matrix:"<<"\n"<<transformation_matrix<<std::endl;
        return (true);
    }
    else
    {
        PCL_ERROR ("\nICP has not converged.\n");
        return (false);
    }
}

////match pylon
//void match::transformation()
//{
//    pcl::PointCloud<pcl::PointXYZ>::Ptr transformed_cloud (new pcl::PointCloud<pcl::PointXYZ>);
//    //NOTE: it is wrong to use pcl::transformPointCloud
//    transformed_cloud->width    = cloud_pylon_2match_f->points.size();
//    transformed_cloud->height   = 1;
//    transformed_cloud->points.resize (transformed_cloud->width);
//    transformed_cloud->is_dense = false;
//    for (size_t i = 0; i < cloud_pylon_2match_f->points.size (); ++i)
//    {
//        //transform cloud_2 to match cloud_1
//        transformed_cloud->points[i].x=cloud_pylon_2match_f->points[i].x*transformation_matrix(0,0)
//                +cloud_pylon_2match_f->points[i].y*transformation_matrix(0,1)
//                +cloud_pylon_2match_f->points[i].z*transformation_matrix(0,2)
//                +transformation_matrix(0,3);
//        transformed_cloud->points[i].y=cloud_pylon_2match_f->points[i].x*transformation_matrix(1,0)
//                +cloud_pylon_2match_f->points[i].y*transformation_matrix(1,1)
//                +cloud_pylon_2match_f->points[i].z*transformation_matrix(1,2)
//                +transformation_matrix(1,3);
//        transformed_cloud->points[i].z=cloud_pylon_2match_f->points[i].x*transformation_matrix(2,0)
//                +cloud_pylon_2match_f->points[i].y*transformation_matrix(2,1)
//                +cloud_pylon_2match_f->points[i].z*transformation_matrix(2,2)
//                +transformation_matrix(2,3);
//    }

//    cloud_merga = *cloud_pylon_need2match_f;
//    cloud_merga += *transformed_cloud;

//}

////match map
//void match::transformation(pcl::PointCloud<pcl::PointXYZ>::Ptr Map1,pcl::PointCloud<pcl::PointXYZ>::Ptr Map2)
//{

//    pcl::PointCloud<pcl::PointXYZ>::Ptr transformed_cloud (new pcl::PointCloud<pcl::PointXYZ>);
//    //NOTE: it is wrong to use pcl::transformPointCloud
//    transformed_cloud->width    = Map2->points.size();
//    transformed_cloud->height   = 1;
//    transformed_cloud->points.resize (transformed_cloud->width);
//    transformed_cloud->is_dense = false;
//    for (size_t i = 0; i < Map2->points.size (); ++i)
//    {
//        //transform cloud_2 to match cloud_1
//        transformed_cloud->points[i].x=Map2->points[i].x*transformation_matrix(0,0)
//                +Map2->points[i].y*transformation_matrix(0,1)
//                +Map2->points[i].z*transformation_matrix(0,2)
//                +transformation_matrix(0,3);
//        transformed_cloud->points[i].y=Map2->points[i].x*transformation_matrix(1,0)
//                +Map2->points[i].y*transformation_matrix(1,1)
//                +Map2->points[i].z*transformation_matrix(1,2)
//                +transformation_matrix(1,3);
//        transformed_cloud->points[i].z=Map2->points[i].x*transformation_matrix(2,0)
//                +Map2->points[i].y*transformation_matrix(2,1)
//                +Map2->points[i].z*transformation_matrix(2,2)
//                +transformation_matrix(2,3);
//    }

//    cloud_merga = *Map1;
//    cloud_merga += *transformed_cloud;

//}
//match map
void match::transformation(pcl::PointCloud<pcl::PointXYZ>::Ptr Map2)
{

    pcl::PointCloud<pcl::PointXYZ>::Ptr transformed_cloud (new pcl::PointCloud<pcl::PointXYZ>);
    cloud_merga.reset(new pcl::PointCloud<pcl::PointXYZ>);
    //NOTE: it is wrong to use pcl::transformPointCloud
    transformed_cloud->width    = Map2->points.size();
    transformed_cloud->height   = 1;
    transformed_cloud->points.resize (transformed_cloud->width);
    transformed_cloud->is_dense = false;
    for (size_t i = 0; i < Map2->points.size (); ++i)
    {
        //transform cloud_2 to match cloud_1
        transformed_cloud->points[i].x=Map2->points[i].x*transformation_matrix(0,0)
                +Map2->points[i].y*transformation_matrix(0,1)
                +Map2->points[i].z*transformation_matrix(0,2)
                +transformation_matrix(0,3);
        transformed_cloud->points[i].y=Map2->points[i].x*transformation_matrix(1,0)
                +Map2->points[i].y*transformation_matrix(1,1)
                +Map2->points[i].z*transformation_matrix(1,2)
                +transformation_matrix(1,3);
        transformed_cloud->points[i].z=Map2->points[i].x*transformation_matrix(2,0)
                +Map2->points[i].y*transformation_matrix(2,1)
                +Map2->points[i].z*transformation_matrix(2,2)
                +transformation_matrix(2,3);
    }

    *cloud_merga += *transformed_cloud;

}
pcl::PointCloud<pcl::PointXYZ> match::transformation_tree_point(pcl::PointCloud<pcl::PointXYZ>::Ptr Map2)
{

    pcl::PointCloud<pcl::PointXYZ>::Ptr transformed_cloud (new pcl::PointCloud<pcl::PointXYZ>);
    //NOTE: it is wrong to use pcl::transformPointCloud
    transformed_cloud->width    = Map2->points.size();
    transformed_cloud->height   = 1;
    transformed_cloud->points.resize (transformed_cloud->width);
    transformed_cloud->is_dense = false;
    for (size_t i = 0; i < Map2->points.size (); ++i)
    {
        //transform cloud_2 to match cloud_1
        transformed_cloud->points[i].x=Map2->points[i].x*transformation_matrix(0,0)
                +Map2->points[i].y*transformation_matrix(0,1)
                +Map2->points[i].z*transformation_matrix(0,2)
                +transformation_matrix(0,3);
        transformed_cloud->points[i].y=Map2->points[i].x*transformation_matrix(1,0)
                +Map2->points[i].y*transformation_matrix(1,1)
                +Map2->points[i].z*transformation_matrix(1,2)
                +transformation_matrix(1,3);
        transformed_cloud->points[i].z=Map2->points[i].x*transformation_matrix(2,0)
                +Map2->points[i].y*transformation_matrix(2,1)
                +Map2->points[i].z*transformation_matrix(2,2)
                +transformation_matrix(2,3);
    }
    return *transformed_cloud;
}
void match::transfer_cloud(pcl::PointCloud<pcl::PointXYZL>::Ptr cloudmo,
                           pcl::PointCloud<pcl::PointXYZ>::Ptr cloudmo_nl,
                           pcl::PointCloud<pcl::PointXYZ>::Ptr cloudsa_nl,
                           pcl::PointCloud<pcl::PointXYZL>::Ptr cloudsa)
{
    //KD树建立
    pcl::KdTreeFLANN<pcl::PointXYZ>kdtree;
    kdtree.setInputCloud(cloudmo_nl);//设置搜索空间
     cloudsa->resize(cloudsa_nl->size());
     cloudsa->width=cloudsa_nl->size();
     cloudsa->height=1;
     cloudsa->is_dense=false;
    // k近邻搜索
    int K = 1;
    std::vector<int>pointIdxNKNSearch(K);//存储搜索到查询点紧邻的索引
    std::vector<float>pointNKNSquaredDistance(K);//存储搜对应的近邻距离平方 ，打印相关信息

    for (size_t i = 0; i < cloudsa_nl->size(); i++) {
        if (kdtree.nearestKSearch(cloudsa_nl->points[i], K, pointIdxNKNSearch, pointNKNSquaredDistance) > 0)//执行k近邻搜索
        {
            cloudsa->points[i].label = cloudmo->points[pointIdxNKNSearch[0]].label;		//将最近邻的标签给该点
        }
    }


}
