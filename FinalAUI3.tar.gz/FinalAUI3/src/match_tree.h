#ifndef MATCH_TREE_H__
#define MATCH_TREE_H__
#include"common.h"
class match_tree
{
public:
    clock_t starttt,enddd;
    int N=100000;
    int MatchTree(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud,
                  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud2,
                  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_tree,
                  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud2_tree,
                  pcl::visualization::PCLVisualizer::Ptr viewer);
};
#endif
