
#ifndef TREEDETACT_H
#define TREEDETACT_H


#include <iostream>
#include <fstream>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/octree/octree.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <Eigen/Dense>
#include <vector>
#include <pcl/visualization/pcl_visualizer.h>

using namespace std;
class treeDetact
{
public:
    treeDetact();
    vector<pcl::PointCloud<pcl::PointXYZ>::Ptr> tree ;
    pcl::PointCloud<pcl::PointXYZ>::Ptr tree_cenrtoid;
    vector<int> correspondence; //index是自己的树木编号，内容是对应树木编号
    vector<double> growth;
    //找到对应树木,并求树木生长
    void dangerDetact( treeDetact B);
    //找到树木的质心
    void getCentroid (pcl::PointCloud<pcl::PointXYZL>::Ptr cloud, int label);
};

class point
{
public:
    float x;
    float y;
    float z;
    int visited = 0;
    int cluster = 0;
    int index = 0;
    vector<int> corepts;
    vector<int> neighbor_pts;
    point() {}
    point(float a, float b, float c)
    {
        x = a;
        y = b;
        z = c;
    }
};


 #endif // TREEDETACT_H
