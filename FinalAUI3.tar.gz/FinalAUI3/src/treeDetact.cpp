#include "ui_mainwindow.h"
#include "treeDetact.h"


float distance(point a, point b) {
   return sqrt((a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y) + (a.z - b.z)*(a.z - b.z));
}

Eigen::MatrixXd Get_gt_centroid(pcl::PointCloud<pcl::PointXYZL>::Ptr cloud, int myLabel,vector<int>&cluster_num) {
   pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_gt(new pcl::PointCloud<pcl::PointXYZ>);			//杆塔点云

   float eps = 0.8;	//八叉树查询邻近点的半径
   int min_pets = 1;
   vector<point> corecloud;
   vector<point> allcloud;



   //提取杆塔点云保存在cloud_gt中
   pcl::PointXYZ pt_gt;
   size_t len1 = cloud->points.size();
   for (size_t i = 0; i < len1; i++) {
       if (cloud->points[i].label == myLabel) {
           pt_gt.x = cloud->points[i].x;
           pt_gt.y = cloud->points[i].y;
           pt_gt.z = cloud->points[i].z;
           (*cloud_gt).push_back(pt_gt);
       }
   }

   float resolution = 1.0f;								//八叉树的分辨率
   pcl::octree::OctreePointCloudSearch<pcl::PointXYZ> octree(resolution);		//初始化八叉树
   octree.setInputCloud(cloud_gt);								//建立杆塔点云的八叉树
   octree.addPointsFromInputCloud();

   size_t len = cloud_gt->points.size();
   for (size_t i = 0; i < len; i++)		 //将所有杆塔点云复制到allcloud中
   {
       point pt = point(cloud_gt->points[i].x, cloud_gt->points[i].y, cloud_gt->points[i].z);
       allcloud.push_back(pt);
   }

   //寻找核心点并把它们放进corecloud
   for (size_t i = 0; i < len; i++)
   {
       vector<int> radiussearch;		//储存邻近点的索引
       vector<float> radiusdistance;	//储存邻近点距离的平方
       octree.radiusSearch(cloud_gt->points[i], eps, radiussearch, radiusdistance);//八叉树的邻近点搜索
       if (radiussearch.size() > min_pets)
       {
           allcloud[i].index = i;					 //在allcloud中储存核心点的坐标
           corecloud.push_back(allcloud[i]);
           allcloud[i].neighbor_pts = radiussearch; //在allcloud中储存邻近点的索引
       }
   }

   //将corecloud的点坐标复制到corecloud1（PointCloud结构）
   pcl::PointCloud<pcl::PointXYZ>::Ptr corecloud1(new pcl::PointCloud<pcl::PointXYZ>);
   corecloud1->points.resize(corecloud.size());
   for (size_t i = 0; i < corecloud.size(); i++)
   {
       corecloud1->points[i].x = corecloud[i].x;
       corecloud1->points[i].y = corecloud[i].y;
       corecloud1->points[i].z = corecloud[i].z;
   }


   //找出每个核心点的密度可达点
   pcl::octree::OctreePointCloudSearch<pcl::PointXYZ> octree1(resolution);
   octree1.setInputCloud(corecloud1);
   octree1.addPointsFromInputCloud();
   for (int i = 0; i < corecloud.size(); i++)
   {
       vector<int> pointIdxNKNSearch;
       vector<float> pointRadiusSquaredDistance;
       octree1.radiusSearch(corecloud1->points[i], eps, pointIdxNKNSearch, pointRadiusSquaredDistance);
       for (size_t j = 0; j < pointIdxNKNSearch.size(); j++)
       {
           corecloud[i].corepts.push_back(pointIdxNKNSearch[j]);
       }
   }

   //根据相邻核心点的密度是否可达，改变每个核心点的聚类值
   int outcluster = 0;
   vector<int> cluster_pts_num;
   for (int i = 0; i < corecloud.size(); i++)
   {
       int pts_num = 0;
       stack<point*> ps;
       if (corecloud[i].visited == 1) continue;
       corecloud[i].cluster = outcluster;
       ps.push(&corecloud[i]);
       point *v;
       //计算每个点的簇值
       while (!ps.empty())
       {
           v = ps.top();
           v->visited = 1;
           allcloud[v->index].visited = 1;
           for (int pts_i = 0; pts_i < allcloud[v->index].neighbor_pts.size(); pts_i++)
           {
               if (allcloud[allcloud[v->index].neighbor_pts[pts_i]].visited == 1)
                   continue;
               else
               {
                   allcloud[allcloud[v->index].neighbor_pts[pts_i]].cluster = outcluster;
                   allcloud[allcloud[v->index].neighbor_pts[pts_i]].visited = 1;
                   pts_num++;
               }
           }

           ps.pop();
           for (int j = 0; j < v->corepts.size(); j++)
           {
               if (corecloud[v->corepts[j]].visited == 1)
                   continue;
               corecloud[v->corepts[j]].cluster = corecloud[i].cluster;
               corecloud[v->corepts[j]].visited = 1;
               allcloud[corecloud[v->corepts[j]].index].cluster = outcluster;
               allcloud[corecloud[v->corepts[j]].index].visited = 1;
               pts_num++;
               for (int pts_i = 0; pts_i < allcloud[corecloud[v->corepts[j]].index].neighbor_pts.size(); pts_i++)
               {
                   if (allcloud[allcloud[corecloud[v->corepts[j]].index].neighbor_pts[pts_i]].visited == 1)
                       continue;
                   else
                   {
                       allcloud[allcloud[corecloud[v->corepts[j]].index].neighbor_pts[pts_i]].cluster = outcluster;
                       allcloud[allcloud[corecloud[v->corepts[j]].index].neighbor_pts[pts_i]].visited = 1;
                       pts_num++;
                   }
               }
               ps.push(&corecloud[v->corepts[j]]);
           }
       }
       cluster_pts_num.push_back(pts_num);
       outcluster++;
   }

   //寻找质心
   for (int i = 0; i < cluster_pts_num.size(); i++)	//删去多余的分类
   {
       if (cluster_pts_num[i] > 1000)
       {
           cluster_num.push_back(i);
       }
       QApplication::processEvents();
   }

   //求解质心
   Eigen::MatrixXd C = Eigen::MatrixXd::Zero(cluster_num.size(), 3);
   for (int i = 0; i < cluster_num.size(); i++) {
       int num = 0;

       for (int j = 0; j < cloud_gt->points.size(); j++) {
           if (allcloud[j].cluster == cluster_num[i]) {
               C(i, 0) += allcloud[j].x;
               C(i, 1) += allcloud[j].y;
               C(i, 2) += allcloud[j].z;
               num++;
           }
       }
       C(i, 0) /= num;
       C(i, 1) /= num;
       C(i, 2) /= num;
       QApplication::processEvents();
   }
   return C;
}

treeDetact::treeDetact()
{}

void treeDetact::dangerDetact(treeDetact B)
{
    pcl::KdTreeFLANN<pcl::PointXYZ> kdtree;
    kdtree.setInputCloud(B.tree_cenrtoid);
    int K=1;
    std::vector<int>pointIdxNKNSearch(K);
    std::vector<float>pointNKNSquaredDistance(K);
    for (size_t i = 0; i < tree_cenrtoid->size(); i++) {
        if (kdtree.nearestKSearch(tree_cenrtoid->points[i], K, pointIdxNKNSearch, pointNKNSquaredDistance) > 0)	//执行k近邻搜索
        {
            float temp = pointNKNSquaredDistance[0];
            temp = sqrt(temp);
//            std::cout<<"distance="<<temp;
            if(temp<3){
                correspondence.push_back(pointIdxNKNSearch[0]);
                //也应该不用绝对值的。怕演示出玄学，先用了再说
                //而且我这里是通过质心做差来求生长情况，最好应该是用图匹配，次之多点做差取平均，后期再改
                double treeGrowth=fabs(tree_cenrtoid->points[i].z-B.tree_cenrtoid->points[pointIdxNKNSearch[0]].z);
                growth.push_back(treeGrowth);
                //reportb.correspondence.push_back() 不能反向操作的。后面有时间再写
            }

        }
        QApplication::processEvents();
    }
}

void treeDetact::getCentroid(pcl::PointCloud<pcl::PointXYZL>::Ptr cloud, int myLabel){
    //对树木点云求出质心点
        Eigen::MatrixXd C;
        vector<int> cluster_num;
        C = Get_gt_centroid(cloud,myLabel,cluster_num);
        pcl::PointXYZ myPoint;
        tree_cenrtoid.reset(new pcl::PointCloud<pcl::PointXYZ>);
        //这里用了一个全局变量cluster_num不太好，应该在get_gt_centroid里面返回出来的
        for(size_t i=0; i<cluster_num.size(); i++){
            myPoint.x=C(i,0);
            myPoint.y=C(i,1);
            myPoint.z=C(i,2);
//            tree_cenrtoid.reset(new pcl::PointCloud<pcl::PointXYZL>);
            tree_cenrtoid->push_back(myPoint);
            QApplication::processEvents();
        }
        tree_cenrtoid->width = (uint32_t)tree_cenrtoid->points.size();
        tree_cenrtoid->height = 1;


        for(size_t i=0; i<tree_cenrtoid->size(); i++){
            pcl::KdTreeFLANN<pcl::PointXYZ>kdtree;
            pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_nolable(new pcl::PointCloud<pcl::PointXYZ>);
            pcl::copyPointCloud(*cloud,*cloud_nolable);
            kdtree.setInputCloud (cloud_nolable);
            int K =500;
            // k近邻搜索 离目标点最近的k个点
            std::vector<int>pointIdxNKNSearch(K);
            std::vector<float>pointNKNSquaredDistance(K);
            if ( kdtree.nearestKSearch (tree_cenrtoid->points[i], K, pointIdxNKNSearch, pointNKNSquaredDistance) >0 )
            {
                pcl::PointCloud<pcl::PointXYZ>::Ptr test(new pcl::PointCloud<pcl::PointXYZ>);			//电力走廊点云
                for (size_t j=0; j<pointIdxNKNSearch.size (); ++j){
                    pcl::PointXYZ myPoint;
                    myPoint.x=cloud->points[ pointIdxNKNSearch[j] ].x ;
                    myPoint.y=cloud->points[ pointIdxNKNSearch[j] ].y ;
                    myPoint.z=cloud->points[ pointIdxNKNSearch[j] ].z ;
                    test->push_back(myPoint);
                }
                test->width = (uint32_t)test->points.size();
                test->height = 1;
                tree.push_back(test);
            }
            QApplication::processEvents();

        }



}
