﻿#ifndef MOUSE__H___
#define MOUSE__H___
#include"common.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <string>
#include <thread>
#include <chrono>
// structure used to pass arguments to the callback function
struct callback_args{
    pcl::PointCloud<pcl::PointXYZ>::Ptr clicked_points_3d;
    pcl::visualization::PCLVisualizer::Ptr viewerPtr;
}cb_args;
pcl::PointXYZ current_point;
void pp_callback(const pcl::visualization::PointPickingEvent& event, void* args)
{
    struct callback_args* data = (struct callback_args *)args;

    if (event.getPointIndex() == -1)
        return;
    //pcl::PointXYZ current_point;
    event.getPoint(current_point.x, current_point.y, current_point.z);
    data->clicked_points_3d->points.push_back(current_point);

    // Draw clicked points in red:
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> red(data->clicked_points_3d, 255, 0, 0);
    data->viewerPtr->removePointCloud("clicked_points");
    data->viewerPtr->addPointCloud(data->clicked_points_3d, red, "clicked_points");
    data->viewerPtr->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 10, "clicked_points");
    std::cout << current_point.x << " " << current_point.y << " " << current_point.z << std::endl;
}

void mouse(pcl::PointCloud<pcl::PointXYZ>::Ptr myPointCloudPtr, pcl::PointCloud<pcl::PointXYZ>::Ptr myPylon,
           boost::shared_ptr<pcl::visualization::PCLVisualizer>  mypcdviewer,QWidget* win,std::string filename)
{
    mypcdviewer->removeAllPointClouds(0);
    pcl::PointCloud<pcl::PointXYZ>::Ptr clicked_points_3d(new pcl::PointCloud<pcl::PointXYZ>);
    cb_args.clicked_points_3d = clicked_points_3d;

    cb_args.viewerPtr = mypcdviewer;
    //pcl::visualization::PointCloudColorHandlerRandom<pcl::PointXYZ> handler (myPointCloudPtr);
    pcl::visualization::PointCloudColorHandlerGenericField<pcl::PointXYZ> handler (myPointCloudPtr, "z");

    mypcdviewer->addPointCloud(myPointCloudPtr, handler, "cloud_random",0);
    //@todo diff pointcloud diff widowname;how to pass viewer to mouse??
    mypcdviewer->removeShape("text", 0);
    mypcdviewer->addText(filename,50,50,"text",0);
    mypcdviewer->registerPointPickingCallback(pp_callback, (void*)&cb_args);

    next_step=-1;

    while(next_step==-1)
    {
        std::cout<<"you in loop"<<std::endl;
        win->update();
        usleep(1000);
        QApplication::processEvents();
    }
    std::cout<<"size()"<<cb_args.clicked_points_3d->points.size()<<std::endl;
    mypcdviewer->removePointCloud("cloud_random",0);
    mypcdviewer->removePointCloud("clicked_points",0);
    mypcdviewer->removeShape("text", 0);

    mypcdviewer.reset();

    for(int i=0;i<myPointCloudPtr->points.size();++i)
    {
        for(int j=0;j<cb_args.clicked_points_3d->points.size();++j)
        {
            if(abs(myPointCloudPtr->points[i].z-cb_args.clicked_points_3d->points[j].z)<13
                    &abs(myPointCloudPtr->points[i].y-cb_args.clicked_points_3d->points[j].y)<3
                    &abs(myPointCloudPtr->points[i].x-cb_args.clicked_points_3d->points[j].x)<8)
            {
                myPylon->points.push_back(myPointCloudPtr->points[i]);
            }
        }
    }
    myPylon->width = myPylon->points.size();
    myPylon->height = 1;
    myPylon->is_dense = false;

}
#endif
