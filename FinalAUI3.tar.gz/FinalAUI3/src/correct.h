﻿#ifndef CORRECT_H__
#define CORRECT_H__
#include"common.h"
#include"mainwindow.h"
#include"ui_mainwindow.h"
class correctClouds {
public:

    correctClouds(pcl::visualization::PCLVisualizer::Ptr _windowname)
          :viewer_cloud(_windowname)
    {
        clicked_points_3d.reset(new pcl::PointCloud<pcl::PointXYZL>);

        viewer_cloud->registerAreaPickingCallback(&correctClouds::pp_callback, *this);
        //viewer_cloud->registerKeyboardCallback(&correctClouds::keyboardEventOccurred, (void*) this);
        viewer_cloud->registerKeyboardCallback(&correctClouds::keyboardEventOccurred,*this);
    }
    
    ~correctClouds(){}
    //输入点云
    void setInputCloud(pcl::PointCloud<pcl::PointXYZL>::Ptr cloud_);
//    void simpleViewer(QVTKWidget* win);
    //回调函数，修正错分点云类型的
    void pp_callback(const pcl::visualization::AreaPickingEvent& event, void* args);
    void keyboardEventOccurred(const pcl::visualization::KeyboardEvent& event, void* nothing);
    void addlabel(pcl::PointCloud<pcl::PointXYZL>::Ptr &cloud,float label);
    void addcloud(pcl::PointCloud<pcl::PointXYZL>::Ptr &cloud1,
                                 pcl::PointCloud<pcl::PointXYZL>::Ptr &cloud2);
    void addcloud(pcl::PointCloud<pcl::PointXYZL>::Ptr &cloud1,
                  pcl::PointCloud<pcl::PointXYZL>::Ptr &cloud2,
                  pcl::PointCloud<pcl::PointXYZL>::Ptr &cloud3,
                  pcl::PointCloud<pcl::PointXYZL>::Ptr &cloud4,
                  pcl::PointCloud<pcl::PointXYZL>::Ptr &cloud5);

    void getclouds(pcl::PointCloud<pcl::PointXYZL>::Ptr &cloud_p,pcl::PointCloud<pcl::PointXYZL>::Ptr &cloud_n);

protected:
    // Point cloud data
    pcl::PointCloud<pcl::PointXYZL>::Ptr cloud;
    // The picked point
    pcl::PointCloud<pcl::PointXYZL>::Ptr clicked_points_3d;
    // The visualizer
    std::vector<std::vector< int >> cloud_indices;
    pcl::visualization::PCLVisualizer::Ptr viewer_cloud;

    bool flag=false;
    int num = -1;
};
#endif
