#pragma once
#ifndef IO_H__
#define IO_H__
#include"common.h"
/****************************************************************************************\
*                                        IO                                              *
\****************************************************************************************/
class IO
{
public:
    IO(std::string _filetype)
        :filetype(_filetype)
    {

    }

    bool Input(std::string filename);
    bool Output(std::string filename);

    struct Input_object
    {
        pcl::PointCloud<pcl::PointXYZ>::Ptr PointCloudPtr;
        std::vector<double> csvpoints;
    };
    Input_object object;

    //雷达得到的是utm坐标，utm转经纬度
    void convert_utm_lonlat(const pcl::PointXYZ utm_coord, const int utmzone, pcl::PointXYZ &lon_lat_coord);
    //经纬度转坐标
    void  convert_lonlat_utm(const pcl::PointXYZ &lon_lat_coord, pcl::PointXYZ &utm_coord);
    //去标签
    void XYZLtoXYZ(pcl::PointCloud<pcl::PointXYZL>::Ptr cloudwithlabel,pcl::PointCloud<pcl::PointXYZ>::Ptr cloud);
    //点云文件带标签
    void XYZtoXYZL(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud,pcl::PointCloud<pcl::PointXYZL>::Ptr cloudwithlabel);
    //把cloudwithlabel中特定标签的点云提取出来,
    void splitcloud(pcl::PointCloud<pcl::PointXYZL>::Ptr cloudwithlabel,int label,pcl::PointCloud<pcl::PointXYZL>::Ptr &cloud);
    double convertStringToDouble(const std::string &s);

protected:
    pcl::PointCloud<pcl::PointXYZ>::Ptr PointCloudPtr;
    std::string filetype;
//    bool las_I(pcl::PointCloud<pcl::PointXYZ>::Ptr PointCloudPtr,std::string lasfilename);
    bool csv_read(std::string csvfilename,pcl::PointCloud<pcl::PointXYZ>::Ptr PointCloudPtr);
};
#endif
