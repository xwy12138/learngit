#include"match_tree.h"
#include"dspfp.h"
int match_tree::MatchTree(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud,
              pcl::PointCloud<pcl::PointXYZ>::Ptr cloud2,
              pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_tree,
              pcl::PointCloud<pcl::PointXYZ>::Ptr cloud2_tree,
              pcl::visualization::PCLVisualizer::Ptr viewer)
{
//    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);//场景1
//    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud2(new pcl::PointCloud<pcl::PointXYZ>);//场景图2
//    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_tree(new pcl::PointCloud<pcl::PointXYZ>);//场景图1中的树
//    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud2_tree(new pcl::PointCloud<pcl::PointXYZ>);//场景图2中的树
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_tree_select(new pcl::PointCloud<pcl::PointXYZ>);//对应点属性高的图1的树
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud2_tree_select(new pcl::PointCloud<pcl::PointXYZ>);//对应点属性高的图2的树

//    if (pcl::io::loadPCDFile<pcl::PointXYZ>("/home/marco/文档/Lidar_data/pcd/2018-05-28-09-46-22.pcd", *cloud) == -1){
//        std::cerr << "open failed!" << std::endl;
//        return -1;
//    }
//    if (pcl::io::loadPCDFile<pcl::PointXYZ>("/home/marco/文档/Lidar_data/pcd/2018-06-04-09-41-55.pcd", *cloud2) == -1){
//        std::cerr << "open failed!" << std::endl;
//        return -1;
//    }
//    if (pcl::io::loadPCDFile<pcl::PointXYZ>("/home/marco/文档/Lidar_data/pcd/5.pcd", *cloud_tree) == -1){
//        std::cerr << "open failed!" << std::endl;
//        return -1;
//    }
//    if (pcl::io::loadPCDFile<pcl::PointXYZ>("/home/marco/文档/Lidar_data/pcd/5_.pcd", *cloud2_tree) == -1){
//        std::cerr << "open failed!" << std::endl;
//        return -1;
//    }



       pcl::RandomSample<pcl::PointXYZ> rs;
          rs.setInputCloud(cloud_tree);
          rs.setSample(500);
          rs.filter(*cloud_tree);
          rs.setInputCloud(cloud2_tree);
          rs.setSample(500);
          rs.filter(*cloud2_tree);
          rs.setInputCloud(cloud);
          rs.setSample(cloud->size()/30);
          rs.filter(*cloud);
          rs.setInputCloud(cloud2);
          rs.setSample(cloud2->size()/30);
          rs.filter(*cloud2);

    Eigen::MatrixXd A,B,C,D,INV,TR,SOU;
    Eigen::MatrixXd X;
    Eigen::MatrixXd result;

    std::cout<<"0"<<std::endl;
    adjacent_matrix(cloud_tree,A);
    adjacent_matrix(cloud2_tree,B);
    cloud2Matrix(cloud_tree,C);
    cloud2Matrix(cloud2_tree,D);
    std::cout<<"1"<<std::endl;
//             starttt=clock();		//程序开始计时
    X=DSPFP_faster(A,B,C,D,1);
//             enddd=clock();		//程序结束用时
//             double endtime=(double)(enddd-starttt)/CLOCKS_PER_SEC;
//             cout<<"Total time:"<<endtime<<endl;		//s为单位
//             cout<<"Total time:"<<endtime*1000<<"ms"<<endl;	//ms为单位

    std::cout<<"2"<<std::endl;
    result=greedy_assignment(X);
    int *arr;
    int size;
//    arr=findIndex(A,1);
    arr=argequal(result,size);
    dispArr(arr,result.rows());
    std::cout<<"4"<<std::endl;


    select(cloud_tree,cloud2_tree,cloud2_tree_select,cloud_tree_select,arr);
    cloud2Matrix(cloud_tree_select,INV);
    cloud2Matrix(cloud2_tree_select,SOU);


//           starttt=clock();		//程序开始计时
    TR = INV.fullPivHouseholderQr().solve(SOU);
//    TR = INV.fullPivLu().solve(SOU);
//    cout<<"TR="<<TR<<endl;
//    cout<<"INV*TR-SOU="<<endl<<INV*TR-SOU<<endl;
//           enddd=clock();		//程序结束用时
//           double endtime=(double)(enddd-starttt)/CLOCKS_PER_SEC;
//           cout<<"Total time:"<<endtime<<endl;		//s为单位
//           cout<<"Total time:"<<endtime*1000<<"ms"<<endl;	//ms为单位

    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_tr(new pcl::PointCloud<pcl::PointXYZ>);
    Matrix2cloud(INV*TR,cloud_tr);

               viewer->setBackgroundColor(0, 0, 0);
               int vp=0;
               viewer->createViewPort(0.0, 0.0, 1.0, 1.0, vp);

               pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> green(cloud2_tree_select, 0,255, 0);
               pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> white(cloud_tree_select, 255, 255, 255);
               pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> red(cloud_tr, 255, 0, 0);

               viewer->addPointCloud<pcl::PointXYZ>(cloud_tree_select, white, "cloud_tree_select", vp);
               viewer->addPointCloud<pcl::PointXYZ>(cloud2_tree_select, green, "cloud2_tree_select", vp);
               viewer->addPointCloud<pcl::PointXYZ>(cloud_tr, red, "cloud_tr", vp);

               viewer->addText("白色红色分别是两次数据，白色是配准后的数据", 10, 10, "vp text", vp);
               viewer->spin();
               viewer->removeAllPointClouds();
               cout<<"5"<<endl;

        for(size_t i=0; i<cloud2_tree->size(); i++){
            cloud2_tree->points[i].z+=30;
        }
        for(size_t i=0; i<cloud2->size(); i++){
            cloud2->points[i].z+=30;
        }


//    boost::shared_ptr< pcl::visualization::PCLVisualizer > viewer(new pcl::visualization::PCLVisualizer("场景图"));
    viewer->setBackgroundColor(0, 0, 0);
//    int vpp=0;
//    viewer->createViewPort(0.5, 0.0, 1.0, 1.0, vpp);

    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> cloud_handler(cloud, 30, 40, 80);
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> cloud2_handler(cloud2, 60,38 , 0);
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> tree_handler(cloud_tree, 255, 255, 255);
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> tree2_handler(cloud2_tree, 255, 255, 255);

    viewer->addPointCloud<pcl::PointXYZ>(cloud, cloud_handler, "cloud");
    viewer->addPointCloud<pcl::PointXYZ>(cloud2, cloud2_handler, "cloud2");
    viewer->addPointCloud<pcl::PointXYZ>(cloud_tree, tree_handler, "cloud_tree");
    viewer->addPointCloud<pcl::PointXYZ>(cloud2_tree, tree2_handler, "cloud2_tree");

    if(cloud_tree->size()<cloud2_tree->size()){
        for(int i=0,j=0; i<cloud_tree->size();i++,j++){
            if(arr[i]==-1) continue;
            viewer->addLine(cloud_tree->points[i],cloud2_tree->points[arr[i]],std::to_string(-(i+1)));
        }
    }
    else{
        for(int i=0,j=0; i<cloud2_tree->size();i++,j++){
            if(arr[i]==-1) continue;
            viewer->addLine(cloud_tree->points[arr[i]],cloud2_tree->points[i],std::to_string(-(i+1)));
        }
    }

    viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 5, "cloud_tree");
    viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 5, "cloud2_tree");
    viewer->spin();

    std::cout<<"5"<<std::endl;
    delete [] arr;
    return 0;
}








