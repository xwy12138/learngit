#ifndef MATCH_CLOUD_H__
#define MATCH_CLOUD_H__
#include"common.h"
/****************************************************************************************\
*                                      match                                             *
\****************************************************************************************/
class match
{
public:
    //	match(pcl::PointCloud<pcl::PointXYZ>::Ptr _cloud_pylon_need2match,
    //			pcl::PointCloud<pcl::PointXYZ>::Ptr _cloud_pylon_2match);

    match(pcl::PointCloud<pcl::PointXYZ>::Ptr _cloud_pylon_need2match,
          pcl::PointCloud<pcl::PointXYZ>::Ptr _cloud_pylon_2match,
          pcl::PointCloud<pcl::PointXYZ>::Ptr Map1,
          pcl::PointCloud<pcl::PointXYZ>::Ptr Map2)
        :cloud_pylon_need2match(_cloud_pylon_need2match),
          cloud_pylon_2match(_cloud_pylon_2match)
    {

        fliter();
        //IterativeClosestPoint();
        pure_translation();
        transformation(Map2);
        //transformation();
    }
    pcl::PointCloud<pcl::PointXYZ> transformation_tree_point(pcl::PointCloud<pcl::PointXYZ>::Ptr Map2);
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_merga;
    Eigen::Matrix4d transformation_matrix;
    void transfer_cloud(pcl::PointCloud<pcl::PointXYZL>::Ptr cloudmo,
                               pcl::PointCloud<pcl::PointXYZ>::Ptr cloudmo_nl,
                               pcl::PointCloud<pcl::PointXYZ>::Ptr cloudsa_nl,
                               pcl::PointCloud<pcl::PointXYZL>::Ptr cloudsa);
protected:
    //icp iterations

    void fliter();
    bool pure_translation();
    bool IterativeClosestPoint();
    void transformation();
    void transformation(pcl::PointCloud<pcl::PointXYZ>::Ptr Map1,
                        pcl::PointCloud<pcl::PointXYZ>::Ptr Map2);
    void transformation(pcl::PointCloud<pcl::PointXYZ>::Ptr Map2);
    int iterations;

    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_pylon_need2match;
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_pylon_2match;
    pcl::PointCloud<pcl::PointXYZ> cloud_pylon_2match_ff;
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_pylon_need2match_f;
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_pylon_2match_f;
    pcl::PointCloud<pcl::PointXYZ> cloud_pylon_need2match_ff;

};
#endif
