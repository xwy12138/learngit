﻿#include"io.h"
bool IO::Input(std::string filename)
{
//    if(filetype == "las")
//    {
//        pcl::PointCloud<pcl::PointXYZ>::Ptr PointCloudPtr  (new pcl::PointCloud<pcl::PointXYZ>);
//        object.PointCloudPtr = PointCloudPtr;
//        if(las_I(object.PointCloudPtr, filename))
//            return false;
//    }

    if(filetype == "pcd")
    {
        pcl::PointCloud<pcl::PointXYZ>::Ptr PointCloudPtr  (new pcl::PointCloud<pcl::PointXYZ>);
        object.PointCloudPtr = PointCloudPtr;
        pcl::PCDReader pcd;
        if(pcd.read (filename, *object.PointCloudPtr) == -1)
            return -1;

    }
    if(filetype == "csv")
    {
        pcl::PointCloud<pcl::PointXYZ>::Ptr PointCloudPtr  (new pcl::PointCloud<pcl::PointXYZ>);
        object.PointCloudPtr = PointCloudPtr;
        if(csv_read(filename,object.PointCloudPtr) == -1)
            return false;

    }
    //TODO add csv files io
    //if(filetype == "csv")
    //{

    //}
    return true;
}

bool IO::Output(std::string filename)
{
    if(filetype == "pcd")
    {
        pcl::io::savePCDFileASCII(filename, *object.PointCloudPtr);
    }
    //TODO add png files io
    //if(filetype == "png")
    //{

    //}
    return true;
}
//经纬度转utm坐标
void IO::convert_lonlat_utm(const pcl::PointXYZ &lon_lat_coord, pcl::PointXYZ &utm_coord)
{
    //建立投影坐标系到经纬度坐标系的转换
    OGRSpatialReference *RefSource = new OGRSpatialReference;
    RefSource->SetWellKnownGeogCS("WGS84");
    OGRSpatialReference *RefTarget = new OGRSpatialReference;
    RefTarget = RefSource->CloneGeogCS();
    RefTarget->SetProjCS("UTM(WGS84) in northern hemisphere.");
    RefTarget->SetUTM(49, TRUE);


    OGRCoordinateTransformation *poTransform = OGRCreateCoordinateTransformation(RefSource, RefTarget);

    double tempX = lon_lat_coord.x;
    double tempY = lon_lat_coord.y;
    double tempZ = lon_lat_coord.z;

    poTransform->Transform(1, &tempX, &tempY, &tempZ);
    utm_coord.x=(tempX);
    utm_coord.y=(tempY);
    utm_coord.z=(tempZ);

}
//utm转经纬度
void IO::convert_utm_lonlat(const pcl::PointXYZ utm_coord, const int utmzone, pcl::PointXYZ &lon_lat_coord)
{
    //建立投影坐标系到经纬度坐标系的转换
    OGRSpatialReference *RefSource = new OGRSpatialReference;
    RefSource->SetWellKnownGeogCS("WGS84");
    RefSource->SetProjCS("UTM(WGS84) in northern hemisphere.");
    RefSource->SetUTM(utmzone, TRUE);
    OGRSpatialReference *RefTarget = new OGRSpatialReference;
    RefTarget = RefSource->CloneGeogCS();
    OGRCoordinateTransformation *poTranform = OGRCreateCoordinateTransformation(RefSource, RefTarget);

    OGRPoint *poPoint = new OGRPoint();
    double tempx = utm_coord.x;
    double tempy = utm_coord.y;
    double tempz = utm_coord.z;

    poTranform->Transform(1, &tempx, &tempy, NULL);
    lon_lat_coord = pcl::PointXYZ(tempx, tempy, tempz);
}
double IO::convertStringToDouble(const std::string &s)
{
    double val;
    std::strstream ss;
    ss << s;
    ss >> val;
    return val;
}
bool IO::csv_read(std::string csvfilename,pcl::PointCloud<pcl::PointXYZ>::Ptr pointCloudPtr)
{
    ifstream inFile(csvfilename, ios::in);
    std::string lineStr;
    pcl::PointXYZ lon_lat_coord;
    pcl::PointXYZ utm_coord;
    std::vector<std::string> lineArray;

    while (std::getline(inFile, lineStr))
    {
        // 打印整行字符串
        //cout << lineStr << endl;
        // 存成二维表结构
        std::stringstream ss(lineStr);
        std::string str;
        // 按照逗号分隔
        while (std::getline(ss, str, ','))
            lineArray.push_back(str);
    }
    int count = lineArray.size()/3;
    pointCloudPtr->resize(count);
    pointCloudPtr->width = count;
    pointCloudPtr->height = 1;
    pointCloudPtr->is_dense = false;
    for(int i=0;i<lineArray.size()/3;i++)
    {
        lon_lat_coord.x=convertStringToDouble(lineArray[3*i]);
        lon_lat_coord.y=convertStringToDouble(lineArray[3*i+1]);
        lon_lat_coord.z=convertStringToDouble(lineArray[3*i+2]);
        IO::convert_lonlat_utm(lon_lat_coord,utm_coord);

        pointCloudPtr->points[i].x = utm_coord.x;
        pointCloudPtr->points[i].y = utm_coord.y;
        pointCloudPtr->points[i].z = utm_coord.z;
    }

}
//bool IO::las_I(pcl::PointCloud<pcl::PointXYZ>::Ptr PointCloudPtr,std::string lasfilename)
//{

//    std::ifstream ifs;
//    ifs.open(lasfilename, std::ios::in | std::ios::binary);

//    liblas::ReaderFactory f ;
//    liblas::Reader reader = f.CreateWithStream(ifs);
//    liblas::Header const& header = reader.GetHeader();

//    size_t count = header.GetPointRecordsCount();
//    std::cout<<"n:"<<count<<"\n";

//    PointCloudPtr->width = 1;
//    PointCloudPtr->height = count;
//    PointCloudPtr->is_dense = false;
//    PointCloudPtr->resize(count);

//    size_t k = 0;
//    while (reader.ReadNextPoint())
//    {
//        liblas::Point const& p = reader.GetPoint();
//        PointCloudPtr->points[k].x = p.GetX();
//        PointCloudPtr->points[k].y = p.GetY();
//        PointCloudPtr->points[k].z = p.GetZ();
//        ++k;
//    }

//    return 0;
//}
void IO::XYZtoXYZL(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud,pcl::PointCloud<pcl::PointXYZL>::Ptr cloudwithlabel)
{
    pcl::copyPointCloud(*cloud,*cloudwithlabel);
}
void IO::XYZLtoXYZ(pcl::PointCloud<pcl::PointXYZL>::Ptr cloudwithlabel,pcl::PointCloud<pcl::PointXYZ>::Ptr cloud)
{
    pcl::copyPointCloud(*cloudwithlabel,*cloud);
}
void IO::splitcloud(pcl::PointCloud<pcl::PointXYZL>::Ptr cloudwithlabel,int label,pcl::PointCloud<pcl::PointXYZL>::Ptr &cloud)
{
   for(int i=0;i<cloudwithlabel->size();i++)
       if(cloudwithlabel->points[i].label==label)
       {
           cloud->points.push_back(cloudwithlabel->points[i]);
       }
       cloud->resize(cloud->size());
       cloud->width=cloud->size();
       cloud->height=1;
       cloud->is_dense=false;
}

