﻿#pragma once
#ifndef COMMON_H__
#define COMMON_H__
//引用的公共头文件
#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <strstream>
#include <vector>
#include<iomanip>

#include <stdlib.h>
#include <cstdlib>
#include <ctime>
#include <cmath>

#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <boost/shared_ptr.hpp>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/point_cloud.h>
#include <pcl/registration/icp.h>
#include <pcl/filters/radius_outlier_removal.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/common/common.h>
#include <pcl/common/transforms.h>
#include <pcl/filters/random_sample.h>
#include <pcl/filters/extract_indices.h>
#include <ogr_spatialref.h>
#include <ogr_geometry.h>

#include <Eigen/Dense>

#endif

